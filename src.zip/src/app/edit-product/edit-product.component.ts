import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { ProductsService } from '../../service/products.service';

@Component({
  selector: 'app-edit-product',
  standalone: true, // ✅ This is needed
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css'],
  imports: [CommonModule, ReactiveFormsModule] // ✅ This fixes formGroup and *ngIf
})
export class EditProductComponent {
  editProductForm!: FormGroup;
  selectedImageUrl: string = '';
  product: any;

  constructor(
    private fb: FormBuilder,
    private productService: ProductsService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.editProductForm = this.fb.group({
      _id: [{ value: '', disabled: true }],
      name: ['', Validators.required],
      price: [0, [Validators.required, Validators.min(1)]],
      image: [''],
      description: ['', Validators.required],
      category: ['', Validators.required],
      isPopular: ['false', Validators.required],
    });

    const _id = this.route.snapshot.paramMap.get('_id');
    if (_id) {
      this.product = this.productService.getProductById(_id);
      if (this.product) {
        this.editProductForm.patchValue(this.product);
        this.selectedImageUrl = this.product.image;
      } else {
        console.error('Product not found');
      }
    }
  }

  onFileSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.selectedImageUrl = reader.result as string;
        this.editProductForm.patchValue({ image: this.selectedImageUrl });
      };
      reader.readAsDataURL(file);
    }
  }

  edit(): void {
  if (this.editProductForm.valid) {
    const updatedProduct = {
      ...this.editProductForm.getRawValue(),
      _id: this.product._id,
      image: this.selectedImageUrl || this.product.image
    };

    this.productService.update(updatedProduct).subscribe(() => {
      this.productService.updateProduct(updatedProduct); // Update local
      this.router.navigate(['/manageProduct']);
    });
  }
}

}
